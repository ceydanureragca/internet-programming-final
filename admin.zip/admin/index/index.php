<?php
    
    header("location:../index/html/index.php");

  ?>
  