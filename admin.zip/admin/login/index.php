<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Thing</title>
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->

<div class="login-box">
  <h2>Giriş</h2>
  <form action="" method="post">
    <div class="user-box">
      <input type="text" name="" required="">
      <label>Username</label>
    </div>
    <div class="user-box">
      <input type="password" name="" required="">
      <label>Password</label>
    </div>
    <button name="giriş">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      Giriş
</button>
  </form>
  <?php 
  if(isset($_POST["giriş"])){
    $_SESSION["admin"]=true; 
    header("location:..index/html/index.php");
  
  }
  ?>
</div>
<!-- partial -->
  
</body>
</html>
